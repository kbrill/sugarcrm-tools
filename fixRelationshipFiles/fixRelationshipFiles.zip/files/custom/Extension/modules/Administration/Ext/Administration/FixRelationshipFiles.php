<?php
$admin_option_defs=array();
$admin_option_defs['Administration']['FIXRELATIONSHIPFILES']= array('Administration','LBL_FIXRELATIONSHIPFILES','LBL_FIXRELATIONSHIPFILES_DESC','./index.php?module=Administration&action=fixRelationshipFiles');
$admin_group_header[]=array('LBL_FIXRELATIONSHIPFILES','',false,$admin_option_defs);
