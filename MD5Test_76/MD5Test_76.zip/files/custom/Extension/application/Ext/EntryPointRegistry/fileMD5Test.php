<?php
$entry_point_registry['fileMD5Test_progress'] = array(
    'file' => 'custom/fileMD5Test_Progress.php',
    'auth' => false
);