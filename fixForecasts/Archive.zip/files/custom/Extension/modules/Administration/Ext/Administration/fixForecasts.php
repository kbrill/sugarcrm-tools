<?php
/**
 * Created by JetBrains PhpStorm.
 * User: kenbrill
 * Date: 6/13/12
 * Time: 3:01 PM
 * To change this template use File | Settings | File Templates.
 */
$admin_option_defs=array();
$admin_option_defs['Administration']['FIXFORECASTS']= array('Administration','LBL_FIXFORECASTS','LBL_FIXFORECASTS_DESC','./index.php?module=Administration&action=fixForecasts');
//$admin_group_header[]=array('LBL_SWEETDBADMIN','',false,$admin_option_defs);

//$admin_option_defs['Administration']['SUGARMYSQLTUNER']= array('Administration','LBL_SWEETMYSQLTUNER','LBL_SWEETMYSQLTUNER_DESC','./index.php?module=Administration&action=SweetMySQLTuner&skip=0&sql=&command=query');
//$admin_option_defs['Administration']['SUGARREPORTSTEST']= array('Administration','LBL_SWEETREPORTSTEST','LBL_SWEETREPORTSTEST_DESC','./index.php?module=Administration&action=reportTest&skip=0&sql=&command=query');
$admin_group_header[]=array('LBL_FIXFORECASTS','',false,$admin_option_defs);
